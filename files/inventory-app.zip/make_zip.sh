# Run from inventory-app directory
zip -r ../inventory-app.zip *
