<nav class="navbar navbar-default" role="navigation">

<div class="navbar-header">
<a class="navbar-brand" href="/"><i class="fas fa-box-open"></i> Inventory</a>
</div>

<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  <ul class="nav navbar-nav">
    <li>
      <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
    </li>
  </ul>
</div>

</nav>
