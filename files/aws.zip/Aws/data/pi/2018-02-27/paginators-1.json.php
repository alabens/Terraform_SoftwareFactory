<?php
// This file was auto-generated from sdk-root/src/data/pi/2018-02-27/paginators-1.json
return [ 'pagination' => [],];
